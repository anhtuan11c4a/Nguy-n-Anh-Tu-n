import React from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from './ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from './ui/table';
import { 
  Badge 
} from './ui/badge';
import { 
  Trophy, 
  Target, 
  TrendingUp, 
  Award,
  Star,
  Zap,
  Clock
} from 'lucide-react';
import { kpis, users } from '../mockData';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { cn } from '../lib/utils';

const KPIView: React.FC = () => {
  const kpiData = [
    { label: 'Tỷ lệ hoàn thành đúng hạn', value: 92, color: 'bg-[#1a73e8]' },
    { label: 'Thời gian phản hồi sự cố', value: 85, color: 'bg-[#f27d26]' },
    { label: 'Tuân thủ quy trình an toàn', value: 100, color: 'bg-[#28a745]' },
  ];

  return (
    <div className="space-y-6 animate-in zoom-in-95 duration-500">
      <div className="flex flex-col gap-1">
        <h2 className="text-xl font-bold tracking-tight text-[#1a3a5f]">Hiệu quả KPI Phòng (Tháng 05)</h2>
        <p className="text-[13px] text-[#666]">Đánh giá kết quả thực hiện của cá nhân và tổ nhóm.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-none shadow-sm bg-white rounded-lg overflow-hidden border-b-4 border-b-[#1a73e8]">
          <CardContent className="p-5">
            <p className="text-[12px] font-bold text-[#666] uppercase mb-2">Điểm trung bình phòng</p>
            <div className="text-3xl font-bold text-[#1a3a5f]">86.5</div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm bg-white rounded-lg overflow-hidden border-b-4 border-b-[#28a745]">
          <CardContent className="p-5">
            <p className="text-[12px] font-bold text-[#666] uppercase mb-2">Tỷ lệ hoàn thành</p>
            <div className="text-3xl font-bold text-[#1a3a5f]">94.2%</div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm bg-white rounded-lg overflow-hidden border-b-4 border-b-[#f27d26]">
          <CardContent className="p-5">
            <p className="text-[12px] font-bold text-[#666] uppercase mb-2">Phản hồi sự cố</p>
            <div className="text-3xl font-bold text-[#1a3a5f]">18.5p</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-none shadow-sm rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-[#fdfdfd] border-b border-[#eee]">
            <h4 className="text-[14px] font-bold text-[#333]">Chi tiết chỉ số hiệu quả</h4>
          </div>
          <CardContent className="p-5 space-y-6">
            {kpiData.map((item, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between text-[13px]">
                  <span>{item.label}</span>
                  <strong className="font-bold">{item.value}%</strong>
                </div>
                <div className="h-2.5 w-full bg-[#eee] rounded-full overflow-hidden">
                  <div className={cn("h-full transition-all duration-1000", item.color)} style={{ width: `${item.value}%` }} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-[#fdfdfd] border-b border-[#eee]">
            <h4 className="text-[14px] font-bold text-[#333]">Xếp hạng nhân sự tháng</h4>
          </div>
          <div className="overflow-auto">
            <table className="w-full border-collapse text-[13px]">
              <thead className="bg-[#f8f9fa]">
                <tr>
                  <th className="text-left px-4 py-2.5 text-[#666] font-semibold border-b border-[#f0f0f0]">Nhân sự</th>
                  <th className="text-center px-4 py-2.5 text-[#666] font-semibold border-b border-[#f0f0f0]">Điểm</th>
                  <th className="text-right px-4 py-2.5 text-[#666] font-semibold border-b border-[#f0f0f0]">Đánh giá</th>
                </tr>
              </thead>
              <tbody>
                {kpis.map((kpi) => {
                  const user = users.find(u => u.id === kpi.userId);
                  return (
                    <tr key={kpi.userId} className="border-b border-[#f0f0f0]">
                      <td className="px-4 py-2.5 font-medium">{user?.name}</td>
                      <td className="px-4 py-2.5 text-center font-bold text-[#1a73e8]">{kpi.totalScore}</td>
                      <td className="px-4 py-2.5 text-right">
                        <span className="px-2 py-0.5 rounded bg-green-50 text-green-700 text-[11px] font-bold">XUẤT SẮC</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default KPIView;
