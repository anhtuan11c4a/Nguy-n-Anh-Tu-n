import React from 'react';
import { 
  LayoutDashboard, 
  ClipboardList, 
  BarChart3, 
  Settings, 
  Cable, 
  Users, 
  AlertTriangle,
  LogOut,
  ChevronRight,
  Activity
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Bảng điều hành', icon: LayoutDashboard },
    { id: 'tasks', label: 'Kế hoạch công việc', icon: ClipboardList },
    { id: 'progress', label: 'Theo dõi tiến độ', icon: Activity },
    { id: 'kpi', label: 'Báo cáo & KPI', icon: BarChart3 },
    { id: 'master-data', label: 'Quản lý thiết bị', icon: Cable },
    { id: 'docs', label: 'Hồ sơ kỹ thuật', icon: ClipboardList },
    { id: 'settings', label: 'Cấu hình hệ thống', icon: Settings },
  ];

  return (
    <div className="flex flex-col h-full bg-white border-r border-[#e0e0e0] w-[220px] shrink-0 transition-all duration-300">
      <ScrollArea className="flex-1 py-5">
        <nav className="space-y-0">
          {menuItems.map((item) => (
            <div
              key={item.id}
              className={cn(
                "flex items-center gap-3 px-6 py-3 text-sm cursor-pointer transition-all border-l-4",
                activeTab === item.id 
                  ? "bg-[#f0f7ff] text-[#1a73e8] border-l-[#1a73e8] font-semibold" 
                  : "text-[#555] border-l-transparent hover:bg-slate-50"
              )}
              onClick={() => setActiveTab(item.id)}
            >
              <item.icon size={18} className={cn(activeTab === item.id ? "text-[#1a73e8]" : "text-[#888]")} />
              {item.label}
            </div>
          ))}
        </nav>
      </ScrollArea>
    </div>
  );
};

export default Sidebar;
