import React from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Cable, 
  Wrench, 
  Plus, 
  Search,
  ChevronRight,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cableLines, equipments } from '../mockData';

const MasterData: React.FC = () => {
  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col gap-1">
          <h2 className="text-2xl font-bold tracking-tight">Dữ liệu gốc</h2>
          <p className="text-muted-foreground">Quản lý danh mục tuyến cáp, thiết bị và hạng mục kỹ thuật.</p>
        </div>
      </div>

      <Tabs defaultValue="lines" className="w-full">
        <TabsList className="bg-slate-100 p-1 rounded-xl w-fit mb-6">
          <TabsTrigger value="lines" className="rounded-lg px-6 data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Cable size={16} className="mr-2" />
            Tuyến cáp
          </TabsTrigger>
          <TabsTrigger value="equipment" className="rounded-lg px-6 data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Wrench size={16} className="mr-2" />
            Thiết bị
          </TabsTrigger>
        </TabsList>

        <TabsContent value="lines" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="relative w-72">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} />
              <Input placeholder="Tìm tuyến cáp..." className="pl-9 bg-white border-none shadow-sm" />
            </div>
            <Button size="sm" className="gap-2">
              <Plus size={16} />
              Thêm tuyến mới
            </Button>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {cableLines.map((line) => (
              <Card key={line.id} className="border-none shadow-sm hover:shadow-md transition-shadow group cursor-pointer">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{line.name}</CardTitle>
                    <ChevronRight size={18} className="text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                  <CardDescription>{line.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-6 mt-2">
                    <div className="flex flex-col">
                      <span className="text-[10px] uppercase text-muted-foreground font-bold">Số thiết bị</span>
                      <span className="text-lg font-bold">{equipments.filter(e => e.cableLineId === line.id).length}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[10px] uppercase text-muted-foreground font-bold">Trạng thái</span>
                      <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full w-fit">Đang vận hành</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="equipment" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="relative w-72">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} />
              <Input placeholder="Tìm thiết bị..." className="pl-9 bg-white border-none shadow-sm" />
            </div>
            <Button size="sm" className="gap-2">
              <Plus size={16} />
              Thêm thiết bị
            </Button>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-50/50">
                <TableRow>
                  <TableHead>Mã thiết bị</TableHead>
                  <TableHead>Tên thiết bị</TableHead>
                  <TableHead>Tuyến cáp</TableHead>
                  <TableHead>Ngày bảo trì gần nhất</TableHead>
                  <TableHead>Tình trạng</TableHead>
                  <TableHead className="text-right">Hành động</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {equipments.map((eq) => (
                  <TableRow key={eq.id}>
                    <TableCell className="font-mono text-xs font-bold">{eq.id.toUpperCase()}</TableCell>
                    <TableCell className="font-medium">{eq.name}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {cableLines.find(l => l.id === eq.cableLineId)?.name}
                    </TableCell>
                    <TableCell className="text-sm">12/04/2024</TableCell>
                    <TableCell>
                      <span className="text-[10px] font-bold px-2 py-1 rounded bg-green-100 text-green-700">TỐT</span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">Chi tiết</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl flex items-start gap-3">
        <Info className="text-blue-500 mt-0.5" size={18} />
        <div>
          <h4 className="text-sm font-bold text-blue-900">Hướng dẫn quản lý dữ liệu</h4>
          <p className="text-xs text-blue-700 mt-1">
            Dữ liệu gốc là nền tảng để lập kế hoạch công việc. Hãy đảm bảo danh mục thiết bị luôn được cập nhật chính xác theo thực tế vận hành tại các tuyến cáp.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MasterData;
