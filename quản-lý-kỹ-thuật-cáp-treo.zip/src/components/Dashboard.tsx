import React from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from './ui/card';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line
} from 'recharts';
import { 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Activity,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { tasks, users, cableLines } from '../mockData';
import { cn } from '../lib/utils';

const Dashboard: React.FC = () => {
  const stats = [
    { label: 'Tổng công việc tuần', value: 42, color: 'border-b-[#1a73e8]' },
    { label: 'Đã hoàn thành', value: '28 (67%)', color: 'border-b-[#28a745]' },
    { label: 'Đang thực hiện', value: 11, color: 'border-b-[#f27d26]' },
    { label: 'Quá hạn / Sự cố', value: '03', color: 'border-b-[#dc3545]' },
  ];

  const weeklyData = [
    { name: 'Thứ 2', completed: 5, total: 8 },
    { name: 'Thứ 3', completed: 7, total: 10 },
    { name: 'Thứ 4', completed: 4, total: 6 },
    { name: 'Thứ 5', completed: 8, total: 9 },
    { name: 'Thứ 6', completed: 4, total: 9 },
  ];

  const categoryData = [
    { name: 'Bảo trì', value: 45 },
    { name: 'Sự cố', value: 15 },
    { name: 'Kiểm định', value: 25 },
    { name: 'An toàn', value: 15 },
  ];

  const COLORS = ['#1a73e8', '#dc3545', '#f27d26', '#28a745'];

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-4">
        {stats.map((stat, i) => (
          <Card key={i} className={cn("border-none shadow-sm border-b-4 rounded-lg overflow-hidden", stat.color)}>
            <CardContent className="p-4">
              <p className="text-[12px] font-bold text-[#666] uppercase mb-2">{stat.label}</p>
              <h3 className="text-2xl font-bold text-[#1a3a5f]">{stat.value}</h3>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-none shadow-sm rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-[#fdfdfd] border-b border-[#eee]">
            <h4 className="text-[14px] font-bold text-[#333]">Tiến độ công việc theo tuần</h4>
          </div>
          <CardContent className="p-4 h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#666'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#666'}} />
                <Tooltip 
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}}
                />
                <Bar dataKey="completed" name="Hoàn thành" fill="#28a745" radius={[4, 4, 0, 0]} barSize={30} />
                <Bar dataKey="total" name="Tổng cộng" fill="#e0e0e0" radius={[4, 4, 0, 0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-[#fdfdfd] border-b border-[#eee]">
            <h4 className="text-[14px] font-bold text-[#333]">Trạng thái vận hành các tuyến</h4>
          </div>
          <CardContent className="p-4 space-y-4">
            {cableLines.map((line) => (
              <div key={line.id} className="flex items-center justify-between p-3 rounded-md bg-[#f8f9fa] border border-[#eee]">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-3 h-3 rounded-full",
                    line.status === 'operational' ? "bg-[#28a745]" : 
                    line.status === 'maintenance' ? "bg-[#f27d26]" : "bg-[#dc3545]"
                  )} />
                  <div>
                    <p className="text-[13px] font-bold text-[#333]">{line.name}</p>
                    <p className="text-[11px] text-[#888]">{line.location}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={cn(
                    "text-[11px] font-bold px-2 py-0.5 rounded",
                    line.status === 'operational' ? "text-[#28a745] bg-[#e8f5e9]" : 
                    line.status === 'maintenance' ? "text-[#f27d26] bg-[#fff3e0]" : "text-[#dc3545] bg-[#ffebee]"
                  )}>
                    {line.status === 'operational' ? 'ĐANG CHẠY' : 
                     line.status === 'maintenance' ? 'BẢO TRÌ' : 'DỪNG'}
                  </span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-none shadow-sm rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-[#fdfdfd] border-b border-[#eee]">
            <h4 className="text-[14px] font-bold text-[#333]">Phân loại công việc (%)</h4>
          </div>
          <CardContent className="p-4 h-[250px] flex items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="w-1/3 space-y-2">
              {categoryData.map((item, i) => (
                <div key={i} className="flex items-center gap-2 text-[12px]">
                  <div className="w-3 h-3 rounded-full" style={{backgroundColor: COLORS[i % COLORS.length]}} />
                  <span className="text-[#666]">{item.name}</span>
                  <span className="font-bold ml-auto">{item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-[#fdfdfd] border-b border-[#eee]">
            <h4 className="text-[14px] font-bold text-[#333]">Hiệu suất nhân sự (Top 5)</h4>
          </div>
          <CardContent className="p-4 h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={users.slice(0, 5).map(u => ({ name: u.name.split(' ').pop(), score: 80 + Math.random() * 15 }))} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fontSize: 11, fill: '#666'}} width={60} />
                <Tooltip />
                <Bar dataKey="score" fill="#1a73e8" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        <Card className="border-none shadow-sm rounded-lg overflow-hidden flex flex-col">
          <div className="px-4 py-3 bg-[#fdfdfd] border-b border-[#eee] flex items-center justify-between">
            <h4 className="text-[14px] font-bold text-[#333]">Danh sách công việc trọng tâm hôm nay</h4>
            <span className="text-[12px] text-[#1a73e8] cursor-pointer">Xem tất cả ›</span>
          </div>
          <div className="flex-1 overflow-auto">
            <table className="w-full border-collapse text-[13px]">
              <thead className="sticky top-0 bg-[#f8f9fa] z-10">
                <tr>
                  <th className="text-left px-4 py-2.5 text-[#666] font-semibold border-b border-[#f0f0f0]">Mã việc</th>
                  <th className="text-left px-4 py-2.5 text-[#666] font-semibold border-b border-[#f0f0f0]">Hạng mục</th>
                  <th className="text-left px-4 py-2.5 text-[#666] font-semibold border-b border-[#f0f0f0]">Phụ trách</th>
                  <th className="text-left px-4 py-2.5 text-[#666] font-semibold border-b border-[#f0f0f0]">Ưu tiên</th>
                  <th className="text-left px-4 py-2.5 text-[#666] font-semibold border-b border-[#f0f0f0]">Trạng thái</th>
                </tr>
              </thead>
              <tbody>
                {tasks.slice(0, 5).map((task) => (
                  <tr key={task.id} className="hover:bg-slate-50 border-b border-[#f0f0f0]">
                    <td className="px-4 py-2.5 font-mono text-[11px]">{task.id.toUpperCase()}</td>
                    <td className="px-4 py-2.5 font-medium">{task.title}</td>
                    <td className="px-4 py-2.5 text-[#666]">{users.find(u => u.id === task.assigneeId)?.name}</td>
                    <td className="px-4 py-2.5">
                      <span className={cn(
                        "text-[11px] font-bold",
                        task.priority === 'urgent' ? "text-red-600" : "text-slate-600"
                      )}>
                        {task.priority.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className={cn(
                        "px-2 py-0.5 rounded-full text-[11px] font-bold",
                        task.status === 'completed' ? "bg-[#e8f5e9] text-[#2e7d32]" : 
                        task.status === 'in-progress' ? "bg-[#e3f2fd] text-[#1565c0]" : 
                        "bg-[#ffebee] text-[#c62828]"
                      )}>
                        {task.status === 'completed' ? 'Hoàn thành' : task.status === 'in-progress' ? 'Đang làm' : 'Chờ xử lý'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="flex flex-col gap-4">
          <Card className="border-none shadow-sm rounded-lg overflow-hidden">
            <div className="px-4 py-3 bg-[#fdfdfd] border-b border-[#eee]">
              <h4 className="text-[14px] font-bold text-[#333]">Hiệu quả KPI Phòng (Tháng 05)</h4>
            </div>
            <CardContent className="p-4 space-y-4">
              {[
                { label: 'Tỷ lệ hoàn thành đúng hạn', value: 92, color: 'bg-[#1a73e8]' },
                { label: 'Thời gian phản hồi sự cố', value: 85, color: 'bg-[#f27d26]' },
                { label: 'Tuân thủ quy trình an toàn', value: 100, color: 'bg-[#28a745]' },
              ].map((item, i) => (
                <div key={i} className="space-y-1.5">
                  <div className="flex justify-between text-[12px]">
                    <span>{item.label}</span>
                    <strong className="font-bold">{item.value}%</strong>
                  </div>
                  <div className="h-2 w-full bg-[#eee] rounded-full overflow-hidden">
                    <div className={cn("h-full transition-all duration-1000", item.color)} style={{ width: `${item.value}%` }} />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm rounded-lg overflow-hidden flex-1">
            <div className="px-4 py-3 bg-[#fdfdfd] border-b border-[#eee]">
              <h4 className="text-[14px] font-bold text-[#333]">Thông báo & Cảnh báo</h4>
            </div>
            <div className="p-4 space-y-3">
              <div className="p-3 rounded-md bg-[#fff8e1] border-l-4 border-l-[#ffb300] text-[12px]">
                <strong>Quá hạn:</strong> Bảo trì máy biến áp T2 đã trễ 2 ngày.
                <div className="text-[10px] text-[#888] mt-1">10 phút trước</div>
              </div>
              <div className="p-3 rounded-md bg-[#e3f2fd] border-l-4 border-l-[#2196f3] text-[12px]">
                <strong>Lịch nhắc:</strong> Kiểm định cáp định kỳ sẽ diễn ra vào sáng mai.
                <div className="text-[10px] text-[#888] mt-1">1 giờ trước</div>
              </div>
              <div className="p-3 rounded-md bg-[#fff8e1] border-l-4 border-l-[#ffb300] text-[12px]">
                <strong>Cảnh báo:</strong> Nhiệt độ động cơ chính Tuyến 1 tăng cao (45°C).
                <div className="text-[10px] text-[#888] mt-1">3 giờ trước</div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
