import React, { useState } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Badge 
} from '@/components/ui/badge';
import { 
  Button 
} from '@/components/ui/button';
import { 
  Input 
} from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Search, 
  Plus, 
  Filter, 
  MoreVertical, 
  Calendar as CalendarIcon,
  User as UserIcon,
  Tag,
  AlertTriangle
} from 'lucide-react';
import { tasks, users, cableLines } from '../mockData';
import { TaskStatus, TaskPriority, TaskCategory } from '../types';
import { cn } from '@/lib/utils';

const TaskList: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          task.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: TaskStatus) => {
    switch (status) {
      case 'todo': return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-600">Chưa làm</span>;
      case 'in-progress': return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#e3f2fd] text-[#1565c0]">Đang làm</span>;
      case 'completed': return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#e8f5e9] text-[#2e7d32]">Hoàn thành</span>;
      case 'delayed': return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#ffebee] text-[#c62828]">Trễ hạn</span>;
      case 'cancelled': return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-gray-100 text-gray-600">Hủy</span>;
      default: return null;
    }
  };

  const getPriorityBadge = (priority: TaskPriority) => {
    switch (priority) {
      case 'low': return <span className="text-[11px] text-slate-400">Thấp</span>;
      case 'medium': return <span className="text-[11px] text-blue-500 font-medium">Trung bình</span>;
      case 'high': return <span className="text-[11px] text-orange-500 font-bold">Cao</span>;
      case 'urgent': return <span className="text-[11px] text-red-600 font-bold">Khẩn cấp</span>;
      default: return null;
    }
  };

  const getCategoryLabel = (category: TaskCategory) => {
    const labels: Record<TaskCategory, string> = {
      maintenance: 'Bảo trì',
      safety: 'An toàn',
      incident: 'Sự cố',
      improvement: 'Cải tiến',
      inspection: 'Kiểm định',
      training: 'Đào tạo',
      other: 'Khác'
    };
    return labels[category];
  };

  return (
    <div className="space-y-4 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col gap-1">
          <h2 className="text-xl font-bold tracking-tight text-[#1a3a5f]">Quản lý kế hoạch công việc</h2>
          <p className="text-[13px] text-[#666]">Danh sách kế hoạch và thực hiện công việc kỹ thuật.</p>
        </div>
        <Button className="gap-2 shadow-sm bg-[#1a73e8] hover:bg-[#1557b0] h-9 text-sm">
          <Plus size={16} />
          Tạo kế hoạch mới
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} />
          <Input 
            placeholder="Tìm kiếm công việc..." 
            className="pl-9 h-9 bg-white border-[#e0e0e0] text-[13px]"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px] h-9 bg-white border-[#e0e0e0] text-[13px]">
              <Filter size={14} className="mr-2 text-muted-foreground" />
              <SelectValue placeholder="Trạng thái" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tất cả</SelectItem>
              <SelectItem value="todo">Chưa làm</SelectItem>
              <SelectItem value="in-progress">Đang làm</SelectItem>
              <SelectItem value="completed">Hoàn thành</SelectItem>
              <SelectItem value="delayed">Trễ hạn</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-[#e0e0e0] overflow-hidden">
        <table className="w-full border-collapse text-[13px]">
          <thead className="bg-[#f8f9fa]">
            <tr>
              <th className="text-left px-4 py-3 text-[#666] font-semibold border-b border-[#f0f0f0]">Mã việc</th>
              <th className="text-left px-4 py-3 text-[#666] font-semibold border-b border-[#f0f0f0]">Hạng mục công việc</th>
              <th className="text-left px-4 py-3 text-[#666] font-semibold border-b border-[#f0f0f0]">Phụ trách</th>
              <th className="text-left px-4 py-3 text-[#666] font-semibold border-b border-[#f0f0f0]">Ưu tiên</th>
              <th className="text-left px-4 py-3 text-[#666] font-semibold border-b border-[#f0f0f0]">Trạng thái</th>
              <th className="text-right px-4 py-3 text-[#666] font-semibold border-b border-[#f0f0f0]">Tiến độ</th>
            </tr>
          </thead>
          <tbody>
            {filteredTasks.map((task) => (
              <tr key={task.id} className="hover:bg-slate-50 border-b border-[#f0f0f0]">
                <td className="px-4 py-3 font-mono text-[11px] text-[#1a3a5f] font-bold">{task.id.toUpperCase()}</td>
                <td className="px-4 py-3">
                  <div className="font-medium">{task.title}</div>
                  <div className="text-[11px] text-[#888] line-clamp-1">{task.description}</div>
                </td>
                <td className="px-4 py-3 text-[#666]">{users.find(u => u.id === task.assigneeId)?.name}</td>
                <td className="px-4 py-3">{getPriorityBadge(task.priority)}</td>
                <td className="px-4 py-3">{getStatusBadge(task.status)}</td>
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <span className="text-[11px] font-bold">{task.progress}%</span>
                    <div className="w-12 h-1.5 bg-[#eee] rounded-full overflow-hidden">
                      <div 
                        className={cn(
                          "h-full transition-all duration-500",
                          task.progress === 100 ? "bg-[#28a745]" : "bg-[#1a73e8]"
                        )} 
                        style={{ width: `${task.progress}%` }} 
                      />
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TaskList;
